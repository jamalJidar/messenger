﻿using ChatRoom.Services.PersonService;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ChatRoom.Controllers
{
	
	[Route("api/[controller]")]
	[ApiController]
	public class ListPersonApiController : ControllerBase
	{
	}
}
