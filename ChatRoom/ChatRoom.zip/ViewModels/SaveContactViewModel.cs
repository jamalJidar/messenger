﻿namespace ChatRoom.ViewModels
{
	public class SaveContactViewModel
	{

        public Guid Subscribers { get; set; }
    }
}
